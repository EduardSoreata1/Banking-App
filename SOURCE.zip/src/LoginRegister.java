

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.*;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class LoginRegister extends JDialog{
    private JPanel panel1;
    private JButton loginButton;
    private JButton registerButton;
    public LoginRegister(JFrame parent){
        super(parent);
        setVisible(true);
        setTitle("Login");
        setContentPane(panel1);
        setMinimumSize(new Dimension(200,75));
        setModal(true);
        setLocationRelativeTo(parent);
        setDefaultCloseOperation(DISPOSE_ON_CLOSE);
        loginButton.addActionListener(new ActionListener() {

            @Override
            public void actionPerformed(ActionEvent e) {
                setVisible(false);
                dispose();
                Login window2 = new Login(null);
                window2.setVisible(true);
            }
        });
        registerButton.addActionListener(new ActionListener() {

            @Override
            public void actionPerformed(ActionEvent e) {
                setVisible(false);
                dispose();
                Register window2 = new Register(null);
                window2.setVisible(true);
            }
        });
    }
}
