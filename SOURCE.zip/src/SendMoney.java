import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.sql.*;

public class SendMoney extends JDialog{
    public int id, balance;
    public String first_name, last_name, email;
    private JPanel panel1;
    private JLabel insertreceiver;
    private JFormattedTextField emailx;
    private JLabel insertvalue;
    private JFormattedTextField value;
    private JButton submit;
    private JButton mainmenu;

    public SendMoney(JFrame parent, int xD, int balancex){
        super(parent);
        setVisible(true);
        setTitle("Send Money");
        setContentPane(panel1);
        setMinimumSize(new Dimension(450, 250));
        setModal(true);
        setLocationRelativeTo(parent);
        setDefaultCloseOperation(DISPOSE_ON_CLOSE);
        this.id = xD;
        this.balance = balancex;
        mainmenu.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                dispose();
                setVisible(false);
                MainMenu window2 = null;
                window2 = new MainMenu(null,id,balance);
                window2.id = id;
                window2.first_name = first_name;
                window2.last_name = last_name;
                window2.email = email;
                window2.balance = balance;
                window2.setVisible(true);
            }
        });
        submit.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                int x = 0;
                try{
                    FieldsNotFilled.fieldsx(emailx.getText(), value.getText());
                } catch (FieldsException ex) {
                    JOptionPane.showMessageDialog(SendMoney.this,
                            "Please fill in all the fields!",
                            "Try again",
                            JOptionPane.ERROR_MESSAGE);
                    throw new RuntimeException(ex);
                }
                try{
                    EmailCheck.check(emailx.getText());
                } catch (EmailException ex) {
                    JOptionPane.showMessageDialog(SendMoney.this,
                            "Please enter a valid email address!",
                            "Try again",
                            JOptionPane.ERROR_MESSAGE);
                    throw new RuntimeException(ex);
                }
                Connection conn = null;
                conn = ConnectionManager.getConnection();
                try {
                    Statement stmt = conn.createStatement();
                } catch (SQLException ex) {
                    throw new RuntimeException(ex);
                }
                String sql = "SELECT * FROM users WHERE email=?";
                PreparedStatement preparedStatement;
                try {
                    preparedStatement = conn.prepareStatement(sql);
                } catch (SQLException ex) {
                    throw new RuntimeException(ex);
                }
                try {
                    preparedStatement.setString(1,emailx.getText());
                } catch (SQLException ex) {
                    throw new RuntimeException(ex);
                }
                try{
                    EmailCheck.notExist(emailx.getText());
                } catch (EmailException ex) {
                    JOptionPane.showMessageDialog(SendMoney.this,
                            "There is no account registered with this email!",
                            "Try again",
                            JOptionPane.ERROR_MESSAGE);
                    throw new RuntimeException(ex);
                } catch (SQLException ex) {
                    throw new RuntimeException(ex);
                }
                PreparedStatement prepxx;
                try {
                    prepxx = conn.prepareStatement("SELECT * FROM users WHERE id=?");
                } catch (SQLException ex) {
                    throw new RuntimeException(ex);
                }
                try {
                    prepxx.setInt(1,id);
                } catch (SQLException ex) {
                    throw new RuntimeException(ex);
                }
                ResultSet xxx;
                try {
                    xxx = prepxx.executeQuery();
                } catch (SQLException ex) {
                    throw new RuntimeException(ex);
                }
                try {
                    xxx.next();
                } catch (SQLException ex) {
                    throw new RuntimeException(ex);
                }
                try {
                    EmailCheck.sameEmail(emailx.getText(), xxx.getString("email"));
                } catch (EmailException ex) {
                    JOptionPane.showMessageDialog(SendMoney.this,
                            "You can't send money to yourself!",
                            "Try again",
                            JOptionPane.ERROR_MESSAGE);
                    throw new RuntimeException(ex);
                } catch (SQLException ex) {
                    throw new RuntimeException(ex);
                }
                ResultSet rs;
                try {
                    rs = preparedStatement.executeQuery();
                } catch (SQLException ex) {
                    throw new RuntimeException(ex);
                }
                try {
                    rs.next();
                } catch (SQLException ex) {
                    throw new RuntimeException(ex);
                }
                int otherID;
                try {
                    otherID = rs.getInt("id");
                } catch (SQLException ex) {
                    throw new RuntimeException(ex);
                }
                try{
                    numberCheck.fixedSize(value.getText().length());
                    x = Integer.parseInt(value.getText());
                }catch (NumberFormatException ex){
                    JOptionPane.showMessageDialog(SendMoney.this,
                            "Please insert a smaller value!",
                            "Try again",
                            JOptionPane.ERROR_MESSAGE);
                    value.setValue("");
                    throw new RuntimeException(ex);
                }
                    try{
                        withdraw(x,balance);
                } catch (notEnoughMoneyException ex) {
                    JOptionPane.showMessageDialog(SendMoney.this,
                            "Insufficient funds!",
                            "Try again",
                            JOptionPane.ERROR_MESSAGE);
                    value.setValue("");
                    throw new RuntimeException(ex);
                }
                balance = balance - x;
                conn = ConnectionManager.getConnection();
                    try {
                    Statement stmt = conn.createStatement();
                } catch (
                SQLException ex) {
                    throw new RuntimeException(ex);
                }
                preparedStatement = null;
                    try {
                    preparedStatement = conn.prepareStatement("UPDATE users SET balance=? WHERE id=?");
                } catch (SQLException ex) {
                    throw new RuntimeException(ex);
                }
                    try {
                    preparedStatement.setInt(1,balance);
                } catch (SQLException ex) {
                    throw new RuntimeException(ex);
                }
                    try {
                    preparedStatement.setInt(2,id);
                } catch (SQLException ex) {
                    throw new RuntimeException(ex);
                }
                    try {
                    preparedStatement.executeUpdate();
                } catch (SQLException ex) {
                    throw new RuntimeException(ex);
                }
                    try {
                    Statement stmt = conn.createStatement();
                } catch (SQLException ex) {
                    throw new RuntimeException(ex);
                }
                    try {
                    preparedStatement = conn.prepareStatement("INSERT INTO transactions (user_id,other_user_id,type,finished,amount) VALUES(?,?,?,?,?)");
                } catch (SQLException ex) {
                    throw new RuntimeException(ex);
                }
                    try {
                    preparedStatement.setInt(1,id);
                } catch (SQLException ex) {
                    throw new RuntimeException(ex);
                }
                try {
                    preparedStatement.setInt(2,otherID);
                } catch (SQLException ex) {
                    throw new RuntimeException(ex);
                }
                    try {
                    preparedStatement.setString(3,"Send");
                } catch (SQLException ex) {
                    throw new RuntimeException(ex);
                }
                    try {
                    preparedStatement.setInt(4,0);
                } catch (SQLException ex) {
                    throw new RuntimeException(ex);
                }
                    try {
                    preparedStatement.setInt(5,x);
                } catch (SQLException ex) {
                    throw new RuntimeException(ex);
                }
                    try {
                    preparedStatement.executeUpdate();
                } catch (SQLException ex) {
                    throw new RuntimeException(ex);
                }
                    emailx.setValue("");
                    value.setValue("");
                    JOptionPane.showMessageDialog(SendMoney.this,
                        "Money sent successfully! Your balance is: $"+balance+". If the receiver does not accept the transaction, your money will be reverted!",
                        "Balance",
                JOptionPane.INFORMATION_MESSAGE);
            }
            });
            value.addKeyListener(new KeyAdapter() {
                @Override
                public void keyPressed(KeyEvent e) {
                    super.keyPressed(e);
                    char c = e.getKeyChar();
                    value.setEditable(Character.isDigit(c));
                }
            });
    }
    public void withdraw(int x, int balance) throws notEnoughMoneyException {
        if(x > balance)
            throw new notEnoughMoneyException("Insufficient funds!");
    }
}
