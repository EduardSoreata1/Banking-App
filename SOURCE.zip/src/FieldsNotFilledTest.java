import org.junit.Test;

import static org.junit.jupiter.api.Assertions.*;

public class FieldsNotFilledTest {
    @Test
    public void checkAllFieldsAreFilled() throws FieldsException {
        var field = new FieldsNotFilled();
        assertTrue(field.fields("1","123","123123","xxsd","x"));
    }
}