

import javax.swing.*;
import javax.swing.text.BadLocationException;
import javax.swing.text.Document;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.Map;
import java.util.Objects;

public class History extends JDialog{
    public int id, balance;
    public String first_name, last_name, email;
    private JPanel panel;
    private JEditorPane pane;
    private JButton mainmenu;

    List transactions = new List();
    Map<String, Integer> totalvalues = new HashMap<>();

    public History(JFrame parent, int idx) {
        super();
        this.id = idx;
        pane.setEditable(false);
        setVisible(true);
        setTitle("History");
        setContentPane(panel);
        setMinimumSize(new Dimension(700, 500));
        setModal(true);
        setLocationRelativeTo(parent);
        setDefaultCloseOperation(DISPOSE_ON_CLOSE);
        Connection conn = ConnectionManager.getConnection();
        PreparedStatement prepareStatement;
        ResultSet rs;
        try {
            prepareStatement = conn.prepareStatement("SELECT * FROM transactions WHERE user_id=? AND finished=? ORDER BY date DESC");
            prepareStatement.setInt(1,id);
            prepareStatement.setInt(2,1);
            rs = prepareStatement.executeQuery();
            while(rs.next()){
                if(Objects.equals(rs.getString("type"), "Withdrawal") || Objects.equals(rs.getString("type"), "Deposit")){
                    try {
                        Document doc = pane.getDocument();
                        doc.insertString(doc.getLength(), "  $" + rs.getString("amount") + " " + rs.getString("type") + " on " + rs.getString("date") + "\n\n", null);
                    } catch(BadLocationException exc) {
                        exc.printStackTrace();
                    }
                }
                else if(Objects.equals(rs.getString("type"), "Send")){
                    try {
                        Document doc = pane.getDocument();
                        PreparedStatement x = conn.prepareStatement("SELECT * FROM users WHERE id=?");
                        x.setInt(1,rs.getInt("other_user_id"));
                        ResultSet r = x.executeQuery();
                        r.next();
                        doc.insertString(doc.getLength(),"  $" + rs.getString("amount") + " sent to " + r.getString("email") + " on " + rs.getString("date") + "\n\n", null);
                    } catch(BadLocationException exc) {
                        exc.printStackTrace();
                    }
                }
                else try {
                        Document doc = pane.getDocument();
                        PreparedStatement x = conn.prepareStatement("SELECT * FROM users WHERE id=?");
                        x.setInt(1,rs.getInt("other_user_id"));
                        ResultSet r = x.executeQuery();
                        r.next();
                        doc.insertString(doc.getLength(),"  $" + rs.getString("amount") + " received from " + r.getString("email") + " on " + rs.getString("date") + "\n\n", null);
                    } catch(BadLocationException exc) {
                        exc.printStackTrace();
                    }
            }
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
        mainmenu.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                dispose();
                setVisible(false);
                MainMenu window2 = null;
                window2 = new MainMenu(null,id,balance);
                window2.id = id;
                window2.first_name = first_name;
                window2.last_name = last_name;
                window2.email = email;
                window2.balance = balance;
                window2.setVisible(true);
            }
        });
    }
}
