

public interface WithdrawMoney {
    void withdraw(int x, int balance) throws notEnoughMoneyException;
}
