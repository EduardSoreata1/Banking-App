
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import javax.swing.text.PlainDocument;

public class Deposit extends JDialog implements DepositMoney{
    public int id, balance;
    public String first_name, last_name, email;
    private JPanel panel1;
    private JFormattedTextField value;
    private JButton submit;
    private JButton mainmenu;
    private JLabel insertvalue;

    public Deposit(JFrame parent, int xD, int balancex){
        super(parent);
        setVisible(true);
        setTitle("Deposit");
        setContentPane(panel1);
        setMinimumSize(new Dimension(450, 185));
        setModal(true);
        setLocationRelativeTo(parent);
        setDefaultCloseOperation(DISPOSE_ON_CLOSE);
        this.id = xD;
        this.balance = balancex;
        mainmenu.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                dispose();
                setVisible(false);
                MainMenu window2 = null;
                window2 = new MainMenu(null,id,balance);
                window2.id = id;
                window2.first_name = first_name;
                window2.last_name = last_name;
                window2.email = email;
                window2.balance = balance;
                window2.setVisible(true);
            }
        });
        submit.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                int x = 0;
                try{
                    FieldsNotFilled.field(value.getText());
                } catch (FieldsException ex) {
                    JOptionPane.showMessageDialog(Deposit.this,
                            "Please insert a value!",
                            "Try again",
                            JOptionPane.ERROR_MESSAGE);
                    throw new RuntimeException(ex);
                }
                try{
                    numberCheck.fixedSize(value.getText().length());
                    x = Integer.parseInt(value.getText());
                }catch (NumberFormatException ex){
                    JOptionPane.showMessageDialog(Deposit.this,
                            "Please insert a smaller value!",
                            "Try again",
                            JOptionPane.ERROR_MESSAGE);
                    value.setValue("");
                    throw new RuntimeException(ex);
                }
                balance = deposit(x, balance);
                Connection conn = null;
                conn = ConnectionManager.getConnection();
                try {
                    Statement stmt = conn.createStatement();
                } catch (SQLException ex) {
                    throw new RuntimeException(ex);
                }
                PreparedStatement preparedStatement = null;
                try {
                    preparedStatement = conn.prepareStatement("UPDATE users SET balance=? WHERE id=?");
                } catch (SQLException ex) {
                    throw new RuntimeException(ex);
                }
                try {
                    preparedStatement.setInt(1,balance);
                } catch (SQLException ex) {
                    throw new RuntimeException(ex);
                }
                try {
                    preparedStatement.setInt(2,id);
                } catch (SQLException ex) {
                    throw new RuntimeException(ex);
                }
                try {
                    preparedStatement.executeUpdate();
                } catch (SQLException ex) {
                    throw new RuntimeException(ex);
                }
                try {
                    Statement stmt = conn.createStatement();
                } catch (SQLException ex) {
                    throw new RuntimeException(ex);
                }
                try {
                    preparedStatement = conn.prepareStatement("INSERT INTO transactions (user_id,type,amount) VALUES(?,?,?)");
                } catch (SQLException ex) {
                    throw new RuntimeException(ex);
                }
                try {
                    preparedStatement.setInt(1,id);
                } catch (SQLException ex) {
                    throw new RuntimeException(ex);
                }
                try {
                    preparedStatement.setString(2,"Deposit");
                } catch (SQLException ex) {
                    throw new RuntimeException(ex);
                }
                try {
                    preparedStatement.setInt(3,x);
                } catch (SQLException ex) {
                    throw new RuntimeException(ex);
                }
                try {
                    preparedStatement.executeUpdate();
                } catch (SQLException ex) {
                    throw new RuntimeException(ex);
                }
                value.setValue("");
                JOptionPane.showMessageDialog(Deposit.this,
                        "Deposit successful! Your balance is: $"+balance,
                        "Balance",
                        JOptionPane.INFORMATION_MESSAGE);
            }
        });
        value.addKeyListener(new KeyAdapter() {
            @Override
            public void keyPressed(KeyEvent e) {
                super.keyPressed(e);
                char c = e.getKeyChar();
                value.setEditable(Character.isDigit(c));
            }
        });
    }

    public Deposit() {

    }

    public int deposit(int x, int balance){
        x = x + balance;
        return x;
    }
}
