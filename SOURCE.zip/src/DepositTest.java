import org.junit.Test;

import static org.junit.jupiter.api.Assertions.*;

public class DepositTest {
    @Test
    public void checkIfDepositIsCorrect(){
        var dep = new Deposit();
        assertEquals(5+3,dep.deposit(5,3));
    }
}