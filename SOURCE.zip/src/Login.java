

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.*;
import java.sql.Connection;
import java.sql.SQLException;

public class Login extends JDialog{
    private JPanel login_panel;
    private JLabel login;
    private JLabel jEmail;
    private JTextField emailx;
    private JLabel jPassword;
    private JPasswordField passwordx;
    private JButton loginbutton;
    private JLabel accountcheck;
    private JButton register;

    public Login(JFrame parent){
        super(parent);
        setVisible(true);
        setTitle("Login");
        setContentPane(login_panel);
        setMinimumSize(new Dimension(450,325));
        setModal(true);
        setLocationRelativeTo(parent);
        setDefaultCloseOperation(DISPOSE_ON_CLOSE);
        register.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                dispose();
                setVisible(false);
                Register window2 = new Register(null);
                window2.setVisible(true);
            }
        });
        loginbutton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String email = emailx.getText();
                String password = String.valueOf(passwordx.getPassword());

                try {
                    user = getAuthenticatedUser(email, password);
                } catch (SQLException ex) {
                    throw new RuntimeException(ex);
                }
            }
        });
    }
    public User user;
    private User getAuthenticatedUser(String email, String password) throws SQLException {
        try{
            FieldsNotFilled.fieldsx(email,password);
        } catch (FieldsException ex) {
            JOptionPane.showMessageDialog(Login.this,
                    "Please fill in all the fields!",
                    "Try again",
                    JOptionPane.ERROR_MESSAGE);
            throw new RuntimeException(ex);
        }
        try{
            EmailCheck.check(email);
        } catch (EmailException ex) {
            JOptionPane.showMessageDialog(Login.this,
                    "Please enter a valid email address!",
                    "Try again",
                    JOptionPane.ERROR_MESSAGE);
            throw new RuntimeException(ex);
        }
        User user = null;
        Connection conn = null;
        conn = ConnectionManager.getConnection();
        Statement stmt = conn.createStatement();
        String sql = "SELECT * FROM users WHERE email=?";
        PreparedStatement preparedStatement = conn.prepareStatement(sql);
        String checkpass = PasswordHashing.doHash(password);
        preparedStatement.setString(1,email);
        try{
            EmailCheck.notExist(email);
        } catch (EmailException e) {
            JOptionPane.showMessageDialog(Login.this,
                    "There is no account registered with this email!",
                    "Try again",
                    JOptionPane.ERROR_MESSAGE);
            throw new RuntimeException(e);
        }
        ResultSet rs = preparedStatement.executeQuery();
        rs.next();
        String x = rs.getString("password");
        try {
            VerifyPasswords.loginCheck(x,checkpass);
        } catch (WrongPasswordException ex) {
            JOptionPane.showMessageDialog(Login.this,
                    "Incorrect password!",
                    "Try again",
                    JOptionPane.ERROR_MESSAGE);
            throw new RuntimeException(ex);
        }
            user = new User();
            user.id = rs.getInt("id");
            user.first_name = rs.getString("first_name");
            user.last_name = rs.getString("last_name");
            user.email = rs.getString("email");
            user.balance = rs.getInt("balance");
            dispose();
            MainMenu window2 = new MainMenu(null, user.id, user.balance);
            window2.id = user.id;
            window2.first_name = user.first_name;
            window2.last_name = user.last_name;
            window2.email = user.email;
            window2.balance = user.balance;
            setVisible(false);
            window2.setVisible(true);
        return null;
    }
}
