

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.*;

public class Register extends JDialog{
    private JPanel register_panel;
    private JLabel register;
    private JLabel first_name;
    private JTextField first_namex;
    private JTextField last_namex;
    private JTextField emailx;
    private JPasswordField passwordx;
    private JPasswordField confirm_passwordx;
    private JButton registerbutton;
    private JLabel last_name;
    private JLabel jEmail;
    private JLabel jPassword;
    private JLabel confirm_password;
    private JLabel accountcheck;
    private JButton login;

    public Register(JFrame parent){
        super(parent);
        setVisible(true);
        setTitle("Register");
        setContentPane(register_panel);
        setMinimumSize(new Dimension(450,500));
        setModal(true);
        setLocationRelativeTo(parent);
        setDefaultCloseOperation(DISPOSE_ON_CLOSE);
        login.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                dispose();
                setVisible(false);
                Login window2 = new Login(null);
                window2.setVisible(true);
            }
        });
        registerbutton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String first_name = first_namex.getText();
                String last_name = last_namex.getText();
                String email = emailx.getText();
                String password1 = String.valueOf(passwordx.getPassword());
                String password2 = String.valueOf(confirm_passwordx.getPassword());
                try {
                    tryToRegister(first_name,last_name,email,password1,password2);
                } catch (SQLException ex) {
                    throw new RuntimeException(ex);
                }
            }
        });
    }
    private void tryToRegister(String first_name, String last_name, String email, String password1, String password2) throws SQLException {
        try{
            FieldsNotFilled.fields(first_name,last_name,email,password1,password2);
        } catch (FieldsException ex) {
            JOptionPane.showMessageDialog(Register.this,
                    "Please fill in all the fields!",
                    "Try again",
                    JOptionPane.ERROR_MESSAGE);
            throw new RuntimeException(ex);
        }
        try{
            EmailCheck.check(email);
        } catch (EmailException ex) {
            JOptionPane.showMessageDialog(Register.this,
                    "Please enter a valid email address!",
                    "Try again",
                    JOptionPane.ERROR_MESSAGE);
            throw new RuntimeException(ex);
        }
        try {
            VerifyPasswords.registerCheck(password1, password2);
        } catch (WrongPasswordException ex) {
            JOptionPane.showMessageDialog(Register.this,
                    "The passwords do not match!",
                    "Try again",
                    JOptionPane.ERROR_MESSAGE);
            throw new RuntimeException(ex);
        }
        try{
            EmailCheck.alreadyExists(email);
        } catch (EmailException e) {
            JOptionPane.showMessageDialog(Register.this,
                    "This email is already in use!",
                    "Try again",
                    JOptionPane.ERROR_MESSAGE);
            throw new RuntimeException(e);
        }
        String password = PasswordHashing.doHash(password1);
        Connection conn = null;
        conn = ConnectionManager.getConnection();
        Statement stmt = conn.createStatement();
        PreparedStatement preparedStatement = conn.prepareStatement("INSERT INTO users (first_name,last_name,email,password,balance) VALUES (?,?,?,?,?)");
        preparedStatement.setString(1,first_name);
        preparedStatement.setString(2,last_name);
        preparedStatement.setString(3,email);
        preparedStatement.setString(4,password);
        preparedStatement.setInt(5,0);
        preparedStatement.executeUpdate();
        setVisible(false);
        dispose();
        Login window2 = new Login(null);
        window2.setVisible(true);
    }
    public static void main(String[] args){
        Register register = new Register(null);
    }
}
