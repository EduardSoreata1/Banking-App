
public class User {
    public int id, balance;
    public String first_name, last_name, email, password, user_type;
}
