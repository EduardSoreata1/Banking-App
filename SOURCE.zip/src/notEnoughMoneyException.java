
public class notEnoughMoneyException extends Exception{
    public notEnoughMoneyException(String str){
        super(str);
    }
}
