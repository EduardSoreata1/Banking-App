

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.*;
import java.util.HashMap;
import java.util.Map;
import java.util.Objects;

public class MainMenu extends JDialog{
    private JButton balancebutton;
    private JPanel panel1;
    private JButton historybutton;
    private JButton depositbutton;
    private JButton withdrawbutton;
    private JButton sendmoneybutton;
    private JButton logoutbutton;
    private JButton requestmoneybutton;
    public String first_name, last_name, email;
    public int id, balance;
    public int HASATM;
    public MainMenu(JFrame parent, int xD, int balancex){
        super(parent);
        HASATM = Main.hasATM;
        this.id = xD;
        this.balance = balancex;
        setVisible(true);
        setTitle("Main Menu");
        setContentPane(panel1);
        setMinimumSize(new Dimension(450, 280));
        setModal(true);
        setLocationRelativeTo(parent);
        setDefaultCloseOperation(DISPOSE_ON_CLOSE);
        Connection conn = null;
        conn = ConnectionManager.getConnection();
        try {
            Statement stmt = conn.createStatement();
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
        String sql = "SELECT * FROM transactions where other_user_id=? AND finished=?";
        PreparedStatement preparedStatement = null;
        try {
            preparedStatement = conn.prepareStatement(sql);
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
        try {
            preparedStatement.setInt(1,id);
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
        try {
            preparedStatement.setInt(2,0);
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
        ResultSet rs;
        try {
            rs = preparedStatement.executeQuery();
            while(rs.next()){
                String sqlx = "SELECT * FROM users WHERE id=?";
                PreparedStatement stmtx = null;
                try {
                    stmtx = conn.prepareStatement(sqlx);
                } catch (SQLException e) {
                    throw new RuntimeException(e);
                }
                try {
                    stmtx.setInt(1,rs.getInt("user_id"));
                } catch (SQLException e) {
                    throw new RuntimeException(e);
                }
                ResultSet x = null;
                try {
                    x = stmtx.executeQuery();
                } catch (SQLException e) {
                    throw new RuntimeException(e);
                }
                try {
                    x.next();
                } catch (SQLException e) {
                    throw new RuntimeException(e);
                }
                String useremail = null;
                try {
                    useremail = x.getString("email");
                } catch (SQLException e) {
                    throw new RuntimeException(e);
                }
                int amount = 0;
                try {
                    amount = rs.getInt("amount");
                } catch (SQLException e) {
                    throw new RuntimeException(e);
                }
                Object[] options = {"Accept",
                        "Deny"};
                try {
                    if(Objects.equals(rs.getString("type"), "Send")) {
                        int n = JOptionPane.showOptionDialog(MainMenu.this,
                                useremail + " sent $" + amount,
                                "Sent",
                                JOptionPane.YES_NO_OPTION,
                                JOptionPane.QUESTION_MESSAGE,
                                null,
                                options,
                                options[0]);
                        if (n == JOptionPane.YES_OPTION) {
                                this.balance = balance + amount;
                                PreparedStatement prep1 = conn.prepareStatement("UPDATE users SET balance=? WHERE id=?");
                                prep1.setInt(1,balance);
                                prep1.setInt(2,id);
                                prep1.executeUpdate();
                                prep1 = conn.prepareStatement("UPDATE transactions SET finished=? WHERE id=?");
                                prep1.setInt(1,1);
                                prep1.setInt(2,rs.getInt("id"));
                                prep1.executeUpdate();
                        } else if (n == JOptionPane.NO_OPTION) {
                                int balancexx = x.getInt("balance");
                                balancexx = balancexx + amount;
                                PreparedStatement prep2 = conn.prepareStatement("UPDATE users SET balance=? WHERE id=?");
                                prep2.setInt(1,balancexx);
                                prep2.setInt(2,x.getInt("id"));
                                prep2.executeUpdate();
                                prep2 = conn.prepareStatement("UPDATE transactions SET finished=? WHERE id=?");
                                prep2.setInt(1,1);
                                prep2.setInt(2,rs.getInt("id"));
                                prep2.executeUpdate();
                        }
                    }
                    else if(Objects.equals(rs.getString("type"), "Request")){
                        int g = JOptionPane.showOptionDialog(MainMenu.this,
                                useremail + " requested $" + amount,
                                "Requested",
                                JOptionPane.YES_NO_OPTION,
                                JOptionPane.QUESTION_MESSAGE,
                                null,
                                options,
                                options[0]);
                        if (g == JOptionPane.YES_OPTION) {
                            try{
                                withdraw(amount,balance);
                                this.balance = balance - amount;
                                PreparedStatement prep3 = conn.prepareStatement("UPDATE users SET balance=? WHERE id=?");
                                prep3.setInt(1,balance);
                                prep3.setInt(2,id);
                                prep3.executeUpdate();
                                int balancexx = x.getInt("balance");
                                balancexx = balancexx + amount;
                                prep3 = conn.prepareStatement("UPDATE users SET balance=? WHERE id=?");
                                prep3.setInt(1,balancexx);
                                prep3.setInt(2,x.getInt("id"));
                                prep3.executeUpdate();
                                prep3 = conn.prepareStatement("UPDATE transactions SET finished=? WHERE id=?");
                                prep3.setInt(1,1);
                                prep3.setInt(2,rs.getInt("id"));
                                prep3.executeUpdate();
                            } catch (notEnoughMoneyException ex) {
                                JOptionPane.showMessageDialog(MainMenu.this,
                                        "Insufficient funds!",
                                        "Try again",
                                        JOptionPane.ERROR_MESSAGE);
                            }
                        } else if (g == JOptionPane.NO_OPTION) {
                            PreparedStatement prep4 = conn.prepareStatement("UPDATE transactions SET finished=? WHERE id=?");
                            prep4.setInt(1,1);
                            prep4.setInt(2,rs.getInt("id"));
                            prep4.executeUpdate();
                        }
                    }
                } catch (SQLException e) {
                    throw new RuntimeException(e);
                }
            }
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
        balancebutton.addActionListener(new ActionListener() {
            int balancexd = balance;
            public void actionPerformed(ActionEvent e) {
                JOptionPane.showMessageDialog(MainMenu.this,
                        "Your balance is: $"+balancexd,
                        "Balance",
                        JOptionPane.INFORMATION_MESSAGE);
            }
        });
        historybutton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                setVisible(false);
                History window2 = new History(null, id);
                window2.id = id;
                window2.first_name = first_name;
                window2.last_name = last_name;
                window2.email = email;
                window2.balance = balance;
                window2.setVisible(true);
            }
        });
        depositbutton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                if(HASATM == 1) {
                    setVisible(false);
                    Deposit window2 = new Deposit(null, id, balance);
                    window2.id = id;
                    window2.first_name = first_name;
                    window2.last_name = last_name;
                    window2.email = email;
                    window2.balance = balance;
                    window2.setVisible(true);
                }
                else{
                    JOptionPane.showMessageDialog(MainMenu.this,
                            "You are not near an ATM!",
                            "No ATM",
                            JOptionPane.INFORMATION_MESSAGE);
                }
            }
        });
        withdrawbutton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if (HASATM == 1) {
                    setVisible(false);
                    Withdraw window2 = new Withdraw(null, id, balance);
                    window2.id = id;
                    window2.first_name = first_name;
                    window2.last_name = last_name;
                    window2.email = email;
                    window2.balance = balance;
                    window2.setVisible(true);
                }
                else{
                    JOptionPane.showMessageDialog(MainMenu.this,
                            "You are not near an ATM!",
                            "No ATM",
                            JOptionPane.INFORMATION_MESSAGE);
                }
            }
        });
        sendmoneybutton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                setVisible(false);
                SendMoney window2 = new SendMoney(null, id, balance);
                window2.id = id;
                window2.first_name = first_name;
                window2.last_name = last_name;
                window2.email = email;
                window2.balance = balance;
                window2.setVisible(true);
            }
        });
        requestmoneybutton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                setVisible(false);
                RequestMoney window2 = new RequestMoney(null, id,balance);
                window2.id = id;
                window2.first_name = first_name;
                window2.last_name = last_name;
                window2.email = email;
                window2.balance = balance;
                window2.setVisible(true);
            }
        });
        logoutbutton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                dispose();
                setVisible(false);
                Login window2 = new Login(null);
                window2.setVisible(true);
            }
        });
    }

    public MainMenu() {

    }

    public void withdraw(int x, int balance) throws notEnoughMoneyException {
        if(x > balance)
            throw new notEnoughMoneyException("Insufficient funds!");
    }
}
