
public class EmailException extends Exception{
    public EmailException(String str){
        super(str);
    }
}
