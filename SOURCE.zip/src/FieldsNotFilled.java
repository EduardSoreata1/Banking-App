

public class FieldsNotFilled extends Exception{
    public static boolean fields(String str1,String str2,String str3,String str4,String str5) throws FieldsException{
        if(str1.length() == 0 || str2.length() == 0 || str3.length() == 0 || str4.length() == 0 || str5.length() == 0)
            throw new FieldsException("Please fill in all the fields!");
        else
            return true;
    }
    public static boolean fieldsx(String str1, String str2)throws FieldsException{
        if(str1.length() == 0 || str2.length() == 0)
            throw new FieldsException("Please fill in all the fields!");
        else
            return true;
    }
    public static boolean field(String str1) throws FieldsException{
        if(str1.length() == 0)
            throw new FieldsException("Please insert a value!");
        else
            return true;
    }
}
