import org.junit.Test;

import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

import static org.junit.jupiter.api.Assertions.*;

public class PasswordHashingTest {
    @Test
    public void doesPasswords(){
        var pass = new PasswordHashing();
        String str = "sxnv84234";
        try{
            MessageDigest messageDigest = MessageDigest.getInstance("SHA");
            messageDigest.update(str.getBytes());
            byte[] resultByteArray = messageDigest.digest();
            StringBuilder sb = new StringBuilder();
            for (byte b : resultByteArray){
                sb.append(String.format("%02x",b));
            }
            str = sb.toString();
        }catch (NoSuchAlgorithmException e){
            e.printStackTrace();
        }
        assertEquals(pass.doHash("sxnv84234"), str);
    }
}