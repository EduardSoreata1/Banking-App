
import java.sql.*;
import java.util.Objects;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class EmailCheck extends Exception{

        public static boolean check(String email) throws EmailException {
            Pattern pattern = Pattern.compile("[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,4}");
            Matcher mat = pattern.matcher(email);
            if(!mat.matches())
                throw new EmailException("Please enter a valid email address!");
            else
                return true;
        }
        public static boolean alreadyExists(String email) throws EmailException, SQLException {
            Connection conn = null;
            conn = ConnectionManager.getConnection();
            Statement stmt = conn.createStatement();
            String sql = "SELECT * FROM users WHERE email=?";
            PreparedStatement preparedStatement = conn.prepareStatement(sql);
            preparedStatement.setString(1,email);
            ResultSet rs = preparedStatement.executeQuery();
            if(rs.next())
                throw new EmailException("This email is already in use!");
            else
                return true;
        }
    public static boolean notExist(String email) throws EmailException, SQLException {
        Connection conn = null;
        conn = ConnectionManager.getConnection();
        Statement stmt = conn.createStatement();
        String sql = "SELECT * FROM users WHERE email=?";
        PreparedStatement preparedStatement = conn.prepareStatement(sql);
        preparedStatement.setString(1,email);
        ResultSet rs = preparedStatement.executeQuery();
        if(!rs.next())
            throw new EmailException("There's no user with this email!");
        else
            return true;
        }
        public static boolean sameEmail(String str1, String str2) throws EmailException, SQLException{
            if(Objects.equals(str1, str2))
                throw new EmailException("You can't send/ request money to/ from yourself.");
            else
                return true;
        }
    }