
public class FieldsException extends Exception{
    FieldsException(String str){
        super(str);
    }
}
