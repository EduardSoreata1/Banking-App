
public interface DepositMoney {
    int deposit(int x,int balance);
}
