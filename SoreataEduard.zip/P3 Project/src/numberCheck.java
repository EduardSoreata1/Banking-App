
import javax.swing.text.PlainDocument;

public class numberCheck extends PlainDocument {
    private static int max = 6;
    public static boolean fixedSize(int a){
        if(a > max)
            throw new NumberFormatException("Number is too large");
        else
            return true;
    }
}
