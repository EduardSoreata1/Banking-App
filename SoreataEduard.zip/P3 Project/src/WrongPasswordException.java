public class WrongPasswordException extends Exception{
    public WrongPasswordException(String str){
        super(str);
    }
}
