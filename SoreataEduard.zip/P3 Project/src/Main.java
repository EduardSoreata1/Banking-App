

import java.util.Objects;
import java.util.Scanner;
import java.util.Arrays;

public class Main{
    public static int hasATM = 0;
    public static void main(String[] args) {
        for(String arg : args)
            if (Objects.equals(arg, "1")) {
                hasATM = 1;
                break;
            }
        LoginRegister lr = new LoginRegister(null);
    }
}