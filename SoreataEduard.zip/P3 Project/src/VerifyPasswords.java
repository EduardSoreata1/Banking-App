

import java.util.Objects;

public class VerifyPasswords extends Exception{
    public static boolean registerCheck(String password1, String password2) throws WrongPasswordException{
        if(!Objects.equals(password1, password2)){
            throw new WrongPasswordException("The passwords do not match!");
        }else
            return true;
    }
    public static boolean loginCheck(String password1, String password2) throws WrongPasswordException{
        if(!Objects.equals(password1, password2)){
            throw new WrongPasswordException("The password is incorrect!");
        }else
            return true;
    }
}
