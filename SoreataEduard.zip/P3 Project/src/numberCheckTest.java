import org.junit.Test;

import static org.junit.jupiter.api.Assertions.*;

public class numberCheckTest {
    @Test
    public void checkIfNumberIsBiggerThan6(){
        var check = new numberCheck();
        assertTrue(check.fixedSize(6));
    }
}