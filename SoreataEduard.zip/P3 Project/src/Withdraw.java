

import javax.swing.*;
import javax.swing.text.NumberFormatter;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.NumberFormat;

public class Withdraw  extends JDialog implements WithdrawMoney {
    public int id, balance;
    public String first_name, last_name, email;
    private JPanel panel1;
    private JLabel insertvalue;
    private JFormattedTextField value;
    private JButton mainmenu;
    private JButton submit;
    public User user;

    public Withdraw(JFrame parent, int xD, int balancex){
        super(parent);
        setVisible(true);
        setTitle("Withdraw");
        setContentPane(panel1);
        setMinimumSize(new Dimension(450, 185));
        setModal(true);
        setLocationRelativeTo(parent);
        setDefaultCloseOperation(DISPOSE_ON_CLOSE);
        this.id = xD;
        this.balance = balancex;
        mainmenu.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                dispose();
                setVisible(false);
                MainMenu window2 = null;
                window2 = new MainMenu(null,id,balance);
                window2.id = id;
                window2.first_name = first_name;
                window2.last_name = last_name;
                window2.email = email;
                window2.balance = balance;
                window2.setVisible(true);
            }
        });
        submit.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                int x = 0;
                try{
                    FieldsNotFilled.field(value.getText());
                } catch (FieldsException ex) {
                    JOptionPane.showMessageDialog(Withdraw.this,
                            "Please insert a value!",
                            "Try again",
                            JOptionPane.ERROR_MESSAGE);
                    throw new RuntimeException(ex);
                }
                try{
                    numberCheck.fixedSize(value.getText().length());
                    x = Integer.parseInt(value.getText());
                }catch (NumberFormatException ex){
                    JOptionPane.showMessageDialog(Withdraw.this,
                            "Please insert a smaller value!",
                            "Try again",
                            JOptionPane.ERROR_MESSAGE);
                    value.setValue("");
                    throw new RuntimeException(ex);
                }
                try{
                    withdraw(x,balance);
                } catch (notEnoughMoneyException ex) {
                    JOptionPane.showMessageDialog(Withdraw.this,
                            "Insufficient funds!",
                            "Try again",
                            JOptionPane.ERROR_MESSAGE);
                    value.setValue("");
                    throw new RuntimeException(ex);
                }
                balance = balance - x;
                Connection conn = null;
                conn = ConnectionManager.getConnection();
                try {
                    Statement stmt = conn.createStatement();
                } catch (SQLException ex) {
                    throw new RuntimeException(ex);
                }
                PreparedStatement preparedStatement = null;
                try {
                    preparedStatement = conn.prepareStatement("UPDATE users SET balance=? WHERE id=?");
                } catch (SQLException ex) {
                    throw new RuntimeException(ex);
                }
                try {
                    preparedStatement.setInt(1,balance);
                } catch (SQLException ex) {
                    throw new RuntimeException(ex);
                }
                try {
                    preparedStatement.setInt(2,id);
                } catch (SQLException ex) {
                    throw new RuntimeException(ex);
                }
                try {
                    preparedStatement.executeUpdate();
                } catch (SQLException ex) {
                    throw new RuntimeException(ex);
                }
                try {
                    Statement stmt = conn.createStatement();
                } catch (SQLException ex) {
                    throw new RuntimeException(ex);
                }
                try {
                    preparedStatement = conn.prepareStatement("INSERT INTO transactions (user_id,type,amount) VALUES(?,?,?)");
                } catch (SQLException ex) {
                    throw new RuntimeException(ex);
                }
                try {
                    preparedStatement.setInt(1,id);
                } catch (SQLException ex) {
                    throw new RuntimeException(ex);
                }
                try {
                    preparedStatement.setString(2,"Withdrawal");
                } catch (SQLException ex) {
                    throw new RuntimeException(ex);
                }
                try {
                    preparedStatement.setInt(3,x);
                } catch (SQLException ex) {
                    throw new RuntimeException(ex);
                }
                try {
                    preparedStatement.executeUpdate();
                } catch (SQLException ex) {
                    throw new RuntimeException(ex);
                }
                value.setValue("");
                JOptionPane.showMessageDialog(Withdraw.this,
                        "Withdrawal successful! Your balance is: $"+balance,
                        "Balance",
                        JOptionPane.INFORMATION_MESSAGE);
            }

        });
        value.addKeyListener(new KeyAdapter() {
            @Override
            public void keyPressed(KeyEvent e) {
                super.keyPressed(e);
                char c = e.getKeyChar();
                value.setEditable(Character.isDigit(c));
            }
        });
    }
    public void withdraw(int x, int balance) throws notEnoughMoneyException {
        if(x > balance)
            throw new notEnoughMoneyException("Insufficient funds!");
    }
}
