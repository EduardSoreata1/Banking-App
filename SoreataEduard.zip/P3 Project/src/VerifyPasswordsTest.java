import org.junit.Test;

import static org.junit.jupiter.api.Assertions.*;

public class VerifyPasswordsTest {
    @Test
    public void checkIfPasswordsMatch() throws WrongPasswordException {
        var pass = new VerifyPasswords();
        assertTrue(pass.registerCheck("bfasy87cfwr","bfasy87cfwr"));
    }
}