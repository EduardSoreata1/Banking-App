import org.junit.Test;
import org.junit.jupiter.api.Assertions;

import java.sql.SQLException;

import static org.junit.jupiter.api.Assertions.*;

public class EmailCheckTest {
    @Test
    public void checkEmailIsNotAlreadyInUse() throws SQLException, EmailException {
        var email = new EmailCheck();
        assertTrue(email.sameEmail("aaab", "aaaa"));
    }
}